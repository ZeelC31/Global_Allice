document.querySelector('.contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    // Here you would typically handle form submission, e.g., send data to a server
    alert('Thank you for your message. We will get back to you soon!');
    this.reset();
});

// Add a floating animation to the contact info section
const contactInfo = document.querySelector('.contact-info');
let floatY = 0;
let floatDirection = 1;

function floatAnimation() {
    floatY += 0.1 * floatDirection;
    if (floatY > 5 || floatY < -5) floatDirection *= -1;
    contactInfo.style.transform = `translateY(${floatY}px)`;
    requestAnimationFrame(floatAnimation);
}

floatAnimation();