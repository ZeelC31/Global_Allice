// Slider functionality
document.addEventListener('DOMContentLoaded', function() {
  function animateCount(elementId, target) {
    const element = document.getElementById(elementId);
    let current = 0;
    const increment = target / 100;
    const timer = setInterval(() => {
      current += increment;
      element.textContent = Math.round(current);
      if (current >= target) {
        clearInterval(timer);
        element.textContent = target;
      }
    }, 20);
  }

  animateCount('countries-count', 50);
  animateCount('projects-count', 100);

  const globe = document.querySelector('.globe');
  
  document.addEventListener('mousemove', function(e) {
    const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
    const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
    globe.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
  });
});


//first slider 
document.addEventListener('DOMContentLoaded', function() {
  function animateCount(elementId, target) {
    const element = document.getElementById(elementId);
    let current = 0;
    const increment = target / 100;
    const timer = setInterval(() => {
      current += increment;
      element.textContent = Math.round(current);
      if (current >= target) {
        clearInterval(timer);
        element.textContent = target;
      }
    }, 20);
  }

  animateCount('countries-count', 2);
  animateCount('projects-count', 100);

  const globe = document.querySelector('.globe');
  
  document.addEventListener('mousemove', function(e) {
    const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
    const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
    globe.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
  });
});


//features 
// Initialize AOS
document.addEventListener('DOMContentLoaded', function() {
    AOS.init({
        duration: 1000,
        once: true,
        offset: 100
    });
});

// Add this to your existing script.js file or in a <script> tag in your HTML

// Feature hover effect
const features = document.querySelectorAll('.feature');

features.forEach(feature => {
    feature.addEventListener('mouseenter', () => {
        feature.style.transform = 'translateY(-10px)';
        feature.style.boxShadow = '0 10px 20px rgba(0, 0, 0, 0.2)';
    });

    feature.addEventListener('mouseleave', () => {
        feature.style.transform = 'translateY(0)';
        feature.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
    });
});

//footer
document.addEventListener('DOMContentLoaded', function() {
    const newsletterForm = document.getElementById('newsletter-form');
    
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = this.querySelector('input[type="email"]').value;
        
        if (validateEmail(email)) {
            // Here you would typically send this to your server
            console.log('Subscribed:', email);
            alert('Thank you for subscribing!');
            this.reset();
        } else {
            alert('Please enter a valid email address.');
        }
    });

    function validateEmail(email) {
        const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }

    // Interactive globe effect
    const globe = document.querySelector('.globe');
    
    document.addEventListener('mousemove', function(e) {
        const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
        const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
        globe.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
    });
});