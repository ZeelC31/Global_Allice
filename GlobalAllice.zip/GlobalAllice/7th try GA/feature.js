//footer
document.addEventListener('DOMContentLoaded', function() {
    const newsletterForm = document.getElementById('newsletter-form');
    
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = this.querySelector('input[type="email"]').value;
        
        if (validateEmail(email)) {
            // Here you would typically send this to your server
            console.log('Subscribed:', email);
            alert('Thank you for subscribing!');
            this.reset();
        } else {
            alert('Please enter a valid email address.');
        }
    });

    function validateEmail(email) {
        const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }

    // Interactive globe effect
    const globe = document.querySelector('.globe');
    
    document.addEventListener('mousemove', function(e) {
        const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
        const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
        globe.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
    });
});

// main section
document.querySelectorAll('.hexagon').forEach(hexagon => {
    hexagon.addEventListener('click', function() {
        const feature = this.getAttribute('data-feature');
        showFeatureSpotlight(feature);
    });
});

function showFeatureSpotlight(feature) {
    const spotlight = document.querySelector('.feature-spotlight');
    const spotlightContents = document.querySelectorAll('.spotlight-content');

    spotlightContents.forEach(content => {
        content.classList.remove('active');
    });

    const activeContent = document.getElementById(feature);
    if (activeContent) {
        spotlight.style.display = 'block';
        activeContent.classList.add('active');

        // Smooth scroll to spotlight
        spotlight.scrollIntoView({ behavior: 'smooth' });
    }
}

// Add a pulsing animation to hexagons
document.querySelectorAll('.hexagon').forEach((hexagon, index) => {
    hexagon.style.animation = `pulse 2s infinite ${index * 0.2}s`;
});

// Add the following CSS for the pulse animation to your styles.css
/*
@keyframes pulse {
    0% {
        transform: scale(1);
    }
    50% {
        transform: scale(1.05);
    }
    100% {
        transform: scale(1);
    }
}
*/