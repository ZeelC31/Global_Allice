document.addEventListener('DOMContentLoaded', function() {
    const newsletterForm = document.getElementById('newsletter-form');
    
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = this.querySelector('input[type="email"]').value;
        
        if (validateEmail(email)) {
            // Here you would typically send this to your server
            console.log('Subscribed:', email);
            alert('Thank you for subscribing!');
            this.reset();
        } else {
            alert('Please enter a valid email address.');
        }
    });
    
    function validateEmail(email) {
        const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }

    // Interactive globe effect
    const globe = document.querySelector('.globe');
    
    document.addEventListener('mousemove', function(e) {
        const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
        const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
        globe.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
    });
});

// Journey section 
document.addEventListener('DOMContentLoaded', function() {
    const timelineItems = document.querySelectorAll('.timeline-item');

    function isElementInViewport(el) {
        const rect = el.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    function handleScroll() {
        timelineItems.forEach(item => {
            if (isElementInViewport(item)) {
                item.classList.add('show');
            }
        });
    }

    // Initial check
    handleScroll();

    // Check on scroll
    window.addEventListener('scroll', handleScroll);
});

/* Our team */
document.addEventListener('DOMContentLoaded', function () {
    const starMap = document.querySelector('.star-map');
    const starBackground = document.querySelector('.star-background');
    const memberInfo = document.querySelector('.member-info');

    const teamMembers = [
        { name: "Zeel Chaudhari", role: "CEO", img: "C:\Users\Hp\Desktop\img formal.jpg" },
        { name: "Gautam Chaudhari", role: "CTO", img: "path_to_john_image.jpg" },
        { name: "Alice Johnson", role: "COO", img: "path_to_alice_image.jpg" },
        { name: "Bob Brown", role: "CFO", img: "path_to_bob_image.jpg" },
        { name: "Carol White", role: "CMO", img: "path_to_carol_image.jpg" }
    ];

    const constellations = [
        { name: "Orion", stars: [[20, 30], [60, 50], [40, 70], [80, 20], [30, 80], [50, 40], [70, 60]] },
        { name: "Ursa Major", stars: [[10, 20], [30, 40], [50, 60], [70, 80], [20, 50], [40, 30], [60, 70]] },
        { name: "Cassiopeia", stars: [[30, 30], [50, 50], [70, 70], [20, 80], [40, 40]] },
        { name: "Lyra", stars: [[25, 35], [45, 55], [65, 75], [85, 25], [35, 65], [55, 45]] },
        { name: "Scorpius", stars: [[15, 25], [35, 45], [55, 65], [75, 85], [25, 15], [45, 35], [65, 55], [85, 75]] }
    ];

    let currentConstellation = 0;

    // Function to create random background stars
    function createBackgroundStars() {
        const numStars = 100;
        for (let i = 0; i < numStars; i++) {
            const star = document.createElement('div');
            star.classList.add('background-star');
            star.style.left = `${Math.random() * 100}%`;
            star.style.top = `${Math.random() * 100}%`;
            starBackground.appendChild(star);
        }
    }

    function createStars(constellation) {
        starMap.innerHTML = ''; // Clear existing stars
        constellation.stars.forEach((pos, index) => {
            const star = document.createElement('div');
            star.classList.add('team-member');
            star.style.left = `${pos[0]}%`;
            star.style.top = `${pos[1]}%`;

            if (index < teamMembers.length) {
                star.addEventListener('mouseenter', (e) => showMemberInfo(e, teamMembers[index]));
                star.addEventListener('mouseleave', () => hideMemberInfo());
            }

            starMap.appendChild(star);
        });
    }

    function showMemberInfo(event, member) {
        if (memberInfo) {
            memberInfo.innerHTML = `
                <img src="${member.img}" alt="${member.name}">
                <div class="text">
                    <h3>${member.name}</h3>
                    <p>${member.role}</p>
                </div>
            `;
            const rect = event.target.getBoundingClientRect();
            const containerRect = starMap.getBoundingClientRect();
            let left = rect.left - containerRect.left + 20;
            let top = rect.top - containerRect.top - 40;
            if (left + 200 > containerRect.width) {
                left = rect.left - containerRect.left - 220;
            }
            if (top < 0) {
                top = rect.top - containerRect.top + 20;
            }
            memberInfo.style.left = `${left}px`;
            memberInfo.style.top = `${top}px`;
            memberInfo.style.opacity = '1';
            memberInfo.style.transform = 'scale(1)';
            memberInfo.style.display = 'block';
        }
    }

    function hideMemberInfo() {
        if (memberInfo) {
            memberInfo.style.opacity = '0';
            memberInfo.style.transform = 'scale(0)';
            memberInfo.style.display = 'none';
        }
    }

    function changeConstellation() {
        createStars(constellations[currentConstellation]);
        currentConstellation = (currentConstellation + 1) % constellations.length;
    }

    // Create background stars once
    createBackgroundStars();

    // Change constellation every 10 seconds
    setInterval(changeConstellation, 5000);
    changeConstellation(); // Initialize the first constellation
});
